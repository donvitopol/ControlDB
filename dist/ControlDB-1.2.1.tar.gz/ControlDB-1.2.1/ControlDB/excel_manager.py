
import os
import pandas as pd
from pprint import pprint


from pretty_logger import PrettyLogger, prettylog

@prettylog
class ExcelManager:
    def __init__(self, logLevel: int = 30) -> None:
        self.logLevel = logLevel
        self.logger: PrettyLogger

    def create_file(self, full_path: str, sheet_name: str = "Sheet1") -> bool:
        """
        Create an empty Excel file with a single sheet.

        Parameters:
        - full_path: Full path where the file will be created.
        - sheet_name: Name of the first sheet.

        Returns:
        - True if created successfully
        - False if failed
        """
        try:
            folder = os.path.dirname(full_path)
            if folder and not os.path.exists(folder):
                os.makedirs(folder)
                self.logger.info(f"📁 Created directory: {folder}")

            with pd.ExcelWriter(full_path, mode="w", engine="openpyxl") as writer:
                pd.DataFrame().to_excel(writer, sheet_name=sheet_name, index=False)

            self.logger.info(f"🆕 New Excel file created at: {full_path} (sheet: {sheet_name})")
            return True
        except Exception:
            self.logger.error(f"❌ Failed to create Excel file: {full_path}", exc_info=True)
            return False

    def upload_dataframe(self, full_path: str, df: pd.DataFrame,
                         sheet_name: str = "Sheet1", mode: str = "w",
                         include_index: bool = True) -> bool:
        """
        Write DataFrame to an Excel file (create file if not present).

        Parameters:
        - full_path: Path to the Excel file
        - df: DataFrame to write
        - sheet_name: Name of the sheet
        - mode: "w" overwrite file, "a" append/replace sheet
        - include_index: Whether to include the DataFrame index in the file
        """
        try:
            if not os.path.exists(full_path) and mode != "w":
                self.logger.warning(f"⚠️ File not found. Creating new file at {full_path}")
                self.create_file(full_path, sheet_name)

            write_mode = "a" if (mode == "a" and os.path.exists(full_path)) else "w"
            with pd.ExcelWriter(full_path, mode=write_mode, engine="openpyxl",
                                if_sheet_exists="replace" if write_mode == "a" else None) as writer:
                df.to_excel(writer, sheet_name=sheet_name, index=include_index)

            self.logger.info(f"✅ DataFrame written to {full_path} (sheet: {sheet_name})")
            return True
        except Exception:
            self.logger.error(f"❌ Failed to upload DataFrame to {full_path}", exc_info=True)
            return False

    def read_file(self, full_path: str, sheet_name: str = None,
                  index_column: str | None = "ID") -> pd.DataFrame | None:
        """
        Read Excel file into a DataFrame.

        Parameters:
        - full_path: Path to the Excel file
        - sheet_name: Sheet to read (default: first sheet)
        - index_column: Column to set as index if present

        Returns:
        - DataFrame with file contents
        - None if failed
        """
        try:
            if not os.path.exists(full_path):
                self.logger.error(f"❌ File not found: {full_path}")
                return None

            df = pd.read_excel(full_path, sheet_name=sheet_name,
                               index_col=index_column if index_column else None)

            self.logger.info(f"📖 Read Excel file {full_path} (sheet: {sheet_name or 'default'})")
            return df
        except Exception:
            self.logger.error(f"❌ Failed to read Excel file: {full_path}", exc_info=True)
            return None

    def update_dataframe(self, full_path: str, df: pd.DataFrame,
                         sheet_name: str = "Sheet1", index_column: str | None = "ID",
                         keep_index: bool = True) -> bool:
        """
        Replace contents of an existing sheet with a new DataFrame.

        Parameters:
        - full_path: Path to Excel file
        - df: DataFrame to write
        - sheet_name: Sheet to update
        - index_column: Column to use as index when saving (default: "ID", set None to disable)
        - keep_index: Whether to include the index in the Excel output
        """
        try:
            if not os.path.exists(full_path):
                self.logger.warning(f"⚠️ File not found. Creating new file at {full_path}")
                self.create_file(full_path, sheet_name)

            if index_column and index_column in df.columns:
                df = df.set_index(index_column, drop=True)

            with pd.ExcelWriter(full_path, mode="a", engine="openpyxl",
                                if_sheet_exists="replace") as writer:
                df.to_excel(writer, sheet_name=sheet_name, index=keep_index)

            self.logger.info(
                f"🔄 Updated sheet '{sheet_name}' in {full_path} "
                f"(index_column='{index_column}', keep_index={keep_index})"
            )
            return True
        except Exception:
            self.logger.error(f"❌ Failed to update sheet in {full_path}", exc_info=True)
            return False

    def merge_dataframe(self, full_path: str, df: pd.DataFrame,
                        sheet_name: str = "Sheet1") -> bool:
        """
        Append a DataFrame to an existing sheet.

        Parameters:
        - full_path: Path to Excel file
        - df: DataFrame to append
        - sheet_name: Sheet to merge with
        """
        try:
            if not os.path.exists(full_path):
                self.logger.warning(f"⚠️ File not found. Creating new file at {full_path}")
                self.create_file(full_path, sheet_name)

            existing_df = self.read_file(full_path, sheet_name=sheet_name)
            combined_df = pd.concat([existing_df, df], ignore_index=True) if existing_df is not None else df

            with pd.ExcelWriter(full_path, mode="a", engine="openpyxl",
                                if_sheet_exists="replace") as writer:
                combined_df.to_excel(writer, sheet_name=sheet_name, index=False)

            self.logger.info(f"➕ Merged DataFrame into {full_path} (sheet: {sheet_name})")
            return True
        except Exception:
            self.logger.error(f"❌ Failed to merge DataFrame into {full_path}", exc_info=True)
            return False

    def get_columns(self, full_path: str, sheet_name: str = None) -> list[str] | None:
        """
        Return a list of column names from an Excel sheet.

        Parameters:
        - full_path: Path to the Excel file
        - sheet_name: Sheet to read (default: first sheet)

        Returns:
        - List of column names
        - None if the file or sheet cannot be read
        """
        try:
            if not os.path.exists(full_path):
                self.logger.warning(f"❌ File not found: {full_path}")
                return None

            df = pd.read_excel(full_path, sheet_name=sheet_name, nrows=0)  # only header
            return df.columns.tolist()
        except Exception as e:
            self.logger.warning(f"❌ Failed to read columns: {e}")
            return None
    
    def remove_file(self, full_path: str) -> bool:
        """
        Remove an Excel file from disk.

        Parameters:
        - full_path: Path to the Excel file to remove

        Returns:
        - True if removed successfully
        - False if failed or file not found
        """
        try:
            if not os.path.exists(full_path):
                self.logger.warning(f"⚠️ File not found, cannot remove: {full_path}")
                return False

            os.remove(full_path)
            self.logger.info(f"🗑️ Removed Excel file: {full_path}")
            return True
        except Exception:
            self.logger.error(f"❌ Failed to remove Excel file: {full_path}", exc_info=True)
            return False












