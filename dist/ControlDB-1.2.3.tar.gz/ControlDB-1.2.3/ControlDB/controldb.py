#!/usr/bin/env python3
"""
ControlDB
===============

Author: Don Vito Pol
Email: don_vito_pol@hotmail.com
Version: 1.0
Created: 2025-09-23

Description:
------------
This module provides tools for managing and interacting with databases.
It supports dynamic table creation, data insertion, updating, and retrieval
using SQLAlchemy and pyodbc.

Usage:
------
>>> from ControlDB import ControlDB
>>> db = ControlDB()
>>> db.connect("MyDB.mdb")
>>> db.add_row(MyTable, column1='value1', column2=123)
>>> row = db.row(MyTable, 1)
>>> print(row)
"""

import os, sys, time, gc
import shutil
import inspect
import functools
import pyodbc
import msaccessdb
import urllib
import pandas as pd
import win32com.client

# from sqlalchemy import create_engine, Engine
from sqlalchemy import Engine, create_engine, MetaData
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import ProgrammingError
from sqlalchemy import (
    Column,
    Integer,      # Whole numbers
    SmallInteger, # Smaller integers
    BigInteger,   # Large integers
    Float,        # Floating point numbers
    Numeric,      # Exact decimal numbers (e.g., money)
    String,       # Varchar / short text
    Text,         # Long text
    Boolean,      # True/False
    Date,         # Date only
    DateTime,     # Date + time
    Time,         # Time only
    LargeBinary,  # Binary data / files
)
from pretty_logger import PrettyLogger

from excel_manager import ExcelManager
from util_manager import UtilManager, UtilGetManager, require_authorization

DATANBASETYPE = "mdb"
 
def construct_folder_path(rootPath:str, folderSystem: str|list[str] = None, levels_up:int=0):
    """
    Constructs the absolute path to a database folder.

    Parameters:
    - folderName (str): The main database folder name.
    - subFolder (str, optional): A subfolder inside the main database folder.
    - levels_up (int, optional): How many directories to move up from the current file (default=3).


    Returns:
    - str: The absolute path to the requested database folder.
    """


    # Add folderName and subFolder if given
    if type(folderSystem)==str:
        return os.path.join(rootPath, folderSystem)
    else:
        return os.path.join(rootPath, *folderSystem)

def construct_file_path(rootPath: str, fileName: str, folderSystem: str|list[str] = None, 
                      levels_up: int = 0, db_type: str = "mdb") -> str:
    """
    Constructs the full file path for a database file.

    Parameters:
    - folderName (str): The name of the user (used as the main folder).
    - fileName (str): The name of the database file (without extension).
    - subFolder (str, optional): A subfolder inside the user's database directory.
    - levels_up (int, optional): How many directories to move up from the current file (default=3).

    Returns:
    - str: The absolute path to the requested database file.
    """

    # ---- Determine file extension based on db_type ----
    # ext = db_type.lower()
    # if ext not in ["mdb", "accdb"]:
    #     raise ValueError(f"Unsupported database type: {db_type}")
    
    # Get the base database path for the user, passing levels_up along
    folderPath = construct_folder_path(rootPath, folderSystem = folderSystem, levels_up=levels_up)

    # Otherwise, return the path to the file inside the user's main database folder
    return os.path.join(folderPath, f"{fileName}.{db_type}")

def construct_name(fileName: str, folderSystem: str|list[str] = None, 
                      levels_up: int = 0, db_type: str = "mdb") -> str:
    """
    Constructs the full file path for a database file.

    Parameters:
    - folderName (str): The name of the user (used as the main folder).
    - fileName (str): The name of the database file (without extension).
    - subFolder (str, optional): A subfolder inside the user's database directory.
    - levels_up (int, optional): How many directories to move up from the current file (default=3).

    Returns:
    - str: The absolute path to the requested database file.
    """

    # Add folderName and subFolder if given
    if type(folderSystem)==str:
        return os.path.join(folderSystem, fileName)
    else:
        return os.path.join(*folderSystem, fileName)


class ControlDB(UtilManager):  
    @property
    def name(self)->str:          
        return self.__name
       
    @property
    def rootPath(self)->int:          
        return self.__rootPath
    
    @property
    def filePath(self)->str:          
        return self.__filePath
    
    @property
    def authorized(self)->dict:          
        return self.__authorized  
    
    def __init__(self,  fileName, rootPath:str=None, folderSystem: str|list[str] = None, db_type: str = "mdb", logLevel: int = 30):
        """
        Initializes the database connection and logger for the ControlDB class.

        Parameters:
        - logLevel (int, optional): The logging level (default is 30, which corresponds to WARNING).
        """   
        self.logLevel: PrettyLogger = logLevel
        
        # Internalize PrettyLogger
        logCtr = PrettyLogger()     
        # Define the module name for logging purposes
        moduleName: str = "ControlDB"
        self.logger:PrettyLogger = logCtr.get(moduleName)  # Retrieve the logger instance for this module
        
        # Add a stream handler to the logger with the specified log level
        logCtr.add_stream(moduleName, level=logLevel)


        super().__init__()   # <- belangrijk!
      
        # Initializing the database engine and session to None
        self.engine: Engine = None
        self.session: Session = None
        self.base:MetaData|list[MetaData] = None

        self.__authorized:bool=False
        self.__name:str
        self.get:UtilGetManager

        self.excel = ExcelManager(logLevel=self.logLevel)

        # Get the absolute path of the current file
        if not rootPath:
            rootPath = os.getcwd()

        self.__rootPath = construct_folder_path(rootPath, folderSystem=folderSystem)
        self.__filePath = construct_file_path(rootPath, fileName, folderSystem=folderSystem, db_type=db_type)
        self.__name = construct_name(fileName, folderSystem=folderSystem)
        
        # Log the initialization of the ControlDB class
        self.logger.debug(f'  - {moduleName} -> __init__') 

    def __set_mdb_password(self, filepath, password):

        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        
        # Open in EXCLUSIVE mode: (Exclusive=True, ReadOnly=False, Connect="")
        db = engine.OpenDatabase(filepath, True, False, ";PWD=")
        
        db.NewPassword("", password)
        db.Close()

        self.logger.info("   -> Password set via COM")
        
    def create_path(self) -> str:
        """
        Creates a folder path for the user (and subfolder if provided).

        Parameters:
        - folderName (str): The name of the user (used as the main folder).
        - subFolder (str, optional): Subfolder inside the user's folder.
        - levels_up (int, optional): How many directories to move up (default=3).

        Returns:
        - str: The created folder path.
        """
        # Build folder path using construct_folder_path
        self.logger.info(f"   -> Create Folder Path")
        self.logger.debug(f"     => Create Folder Path: {self.rootPath}")

        if not os.path.exists(self.rootPath):
            os.makedirs(self.rootPath, exist_ok=True)
            self.logger.info(f"     => Folder Path created.")
        else:
            self.logger.info(f"     => Folder Path present.")

        return self.rootPath
    
    def create_file(self, password: str = "") -> bool:
        """
        Creates a file (MS Access DB) for the user if it does not exist.

        Parameters:
        - folderName (str): The name of the user (used as the main folder).
        - fileName (str): The name of the file (without extension).
        - subFolder (str, optional): Subfolder inside the user's folder.
        - password (str, optional): Password for the file.
        - levels_up (int, optional): How many directories to move up (default=3).

        Returns:
        - str: The created file path.
        """
        
        # Ensure folder system exists
        self.create_path()

        fileNameOnly = os.path.basename(self.filePath)
        self.logger.info(f"   -> Create File {fileNameOnly}")
        self.logger.debug(f"     => File Path: {self.filePath}")

        if not os.path.exists(self.filePath):
            msaccessdb.create(self.filePath)
            self.__set_mdb_password(self.filePath, password)
            self.logger.info("     => File created.")
            return True
        else:
            self.logger.info("     => File present.")
            return False
    
    def setup(self, password: str = "", base: MetaData|list[MetaData] = None, login = True) -> bool:
        """
        Create a new MS Access (or similar) database if it does not already exist, and initialize tables.

        Parameters:
        ----------
        fileName : str
            Database file name (without extension).
        folderSystem : str | list[str], optional
            Folder name or list of nested folders where the database will be stored.
        baseList : object | list[object], optional
            ORM base classes or table schemas to create in the database.
        password : str, optional
            Database password (default="").
        levels_up : int, optional
            Number of parent directories to go up from the current working directory.
        db_type : str, optional
            Database file extension ("mdb" or "accdb").

        Returns:
        - str: Full path to the created (or existing) database file.

        Raises:
        - FileNotFoundError: If the target folder does not exist and cannot be created.
        - ValueError: If db_type is unsupported.
        """
        # Ensure the folder structure exists and create the database file. Apply the given password if provided.   
        self.create_file(password= password)

        # Connect and initialize models
        self.connect(password=password, base=base)

        # Setup given models
        if self.engine is None:
            raise ValueError("[ERROR] SQLAlchemy engine is None — cannot proceed.")  
        
        print(self.base)
        if type(self.base)==list:
            for b in self.base:
                b.metadata.create_all(bind=self.engine) 
        else:     
            self.base.metadata.create_all(bind=self.engine)  

        if not login:
            self.detach()
        

        return True
    
    def connect(self, password: str = "", base: MetaData|list[MetaData] = None) -> bool:
        """
        Connect to an MS Access database and return a SQLAlchemy engine.

        Parameters:
        - folderName (str): Folder where the database is located.
        - fileName (str): Name of the database file without extension.
        - subFolder (str, optional): Optional subfolder inside folderName.
        - password (str, optional): Password for protected databases.
        - levels_up (int, optional): Number of parent directories to go up from current working directory.
        - db_type (str, optional): Type of Access database, "mdb" or "accdb". Defaults to "mdb".

        Returns:
        - Engine: SQLAlchemy engine connected to the database.

        Raises:
        - FileNotFoundError: If the database file does not exist.
        - ConnectionRefusedError: If no valid MS Access ODBC driver is installed.
        - pyodbc.Error: If connection attempt fails.
        """
        
        # ---- Check if the file exists ----
        if not os.path.exists(self.filePath):
            self.logger.error(f"    ❌ - Database file not found: {self.filePath}")
            raise FileNotFoundError(f"Database file does not exist: {self.filePath}")

        # ---- Check for Microsoft Access ODBC driver ----
        msa_drivers = [x for x in pyodbc.drivers() if 'ACCESS' in x.upper()]
        if "Microsoft Access Driver (*.mdb, *.accdb)" not in msa_drivers:
            self.logger.critical("=! Wrong engine installed. Please install 64-bit MS Access Driver.")
            self.logger.info(f"   => Available MS-ACCESS Drivers: {msa_drivers}")
            raise ConnectionRefusedError("No valid MS Access ODBC driver found!")

        try:
            # ---- Build ODBC connection string ----
            con_parts = [r'Driver={Microsoft Access Driver (*.mdb, *.accdb)};',
                        f'DBQ={self.filePath};']

            # ---- Logic for old MDB vs new ACCDB ----
            ext = os.path.splitext(self.filePath)[1][1:]
            if ext == "mdb":
                # Old format requires both UserID and Password
                if password:
                    con_parts.append(f'Uid=Admin;Pwd={password};')
                else:
                    con_parts.append('Uid=Admin;Pwd=;')  # empty password
            else:
                # New ACCDB format: only password is required
                if password:
                    con_parts.append(f'Pwd={password};')
                else:
                    self.logger.warning(" -> ACCDB database not password protected")

            # ---- Combine and URL-encode connection string ----
            con_string = "".join(con_parts)
            connection_url = f"access+pyodbc:///?odbc_connect={urllib.parse.quote_plus(con_string)}"

            # ---- Create SQLAlchemy engine ----
            self.engine = create_engine(connection_url)

            # ---- Test the connection immediately ----
            with self.engine.connect() as conn:
                pass  # test connection

        except pyodbc.Error as e:
            # ---- Specific handling for invalid password ----
            if 'Not a valid password' in str(e):
                self.logger.warning("⛔ Login attempt failed: Invalid password for database.")
                self.__authorized = False
                return False
            else:
                self.logger.error("❌ Failed to connect to Access DB.", exc_info=True)
                self.__authorized = False
                raise

        # ---- Mark as successfully authorized ----
        self.__authorized = True
        
        if base:
            self.base = base
        else:
            self.base = MetaData()


        # ---- Initialize SQLAlchemy session bound to the engine ----
        _Session = sessionmaker(bind=self.engine)
        self.session = _Session()

        # ---- Connect UtilManager using internal method ----
        # Needs to run after session is created
        super().connect()

        # ---- Logging success ----
        fileName_log = self.filePath.ljust(8)
        self.logger.info(f"   -> Connect to database: {self.name} => Connection established successfully.")
        self.logger.debug(f"     => File path of database: {self.filePath}")

        return True
    
    @ require_authorization
    def detach(self):
        try:
            if hasattr(self, "session") and self.session:
                self.session.close()
                self.session = None
                self.logger.debug(" -> Session closed.")

            if self.engine:
                self.engine.dispose()
                self.engine = None
                self.logger.debug(" -> Engine disposed.")

            gc.collect()
            
            # Mark as closed authorized
            self.__authorized = False
            time.sleep(0.4)  # Let OS flush handles
        except Exception as e:
            self.logger.error(f"Error while fully closing database: {e}")
        
    @ require_authorization
    def remove(self, exec: bool = False, retries: int = 5, delay: float = 0.5) -> bool:
        """
        Safely delete a database file with retries and proper connection cleanup.

        Args:
            file (str): Path to the database file (.mdb).
            exec (bool): Whether to execute deletion.
            retries (int): Number of retry attempts if the file is locked.
            delay (float): Delay between retries in seconds.

        Returns:
            bool: True if deleted successfully, False otherwise.
        """
        self.logger.debug(f"  - ControlDB -> remove: {self.filePath}")

        if not exec or not os.path.isfile(self.filePath):
            return False

        # Close all sessions and dispose engine
        self.logger.debug("  -> Closing sessions and disposing engine...")
        try:
            if hasattr(self, "session"):
                self.session.close()
            if hasattr(self, "engine"):
                self.engine.dispose()
        except Exception as e:
            self.logger.warning(f"  -> Could not fully close connections: {e}")

        ldb_file = self.filePath[:-3] + "ldb"

        for attempt in range(1, retries + 1):
            try:
                if os.path.exists(ldb_file):
                    self.logger.warning(f" -> LDB lock file exists: {ldb_file}")
                    # Optional: os.remove(ldb_file)  # only if safe
                os.remove(self.filePath)
                self.logger.info(f"    ✅ - Database file successfully removed: {self.filePath}")
                return True
            except PermissionError:
                self.logger.warning(f"    ⛔ - Retry {attempt}/{retries}")
                time.sleep(delay)

        raise PermissionError(f"Could not remove file after {retries} retries: {self.filePath}. "
                            f"Close any applications using it (Access, DAO, etc.)")

    @ require_authorization
    def remove_folder(self, exec: bool = False)->bool:
        
        if not exec or not os.path.exists(self.rootPath):
            self.logger.warning(f"   => Folder does not exist. Path: '{self.rootPath}'.")
            return False
        else:
            shutil.rmtree(self.rootPath)  # Remove the folder and everything inside it
            self.logger.debug(f"   => Folder has been removed. Path: '{self.rootPath}'.")
            return True