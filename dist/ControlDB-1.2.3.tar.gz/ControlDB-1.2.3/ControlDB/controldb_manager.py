import os, sys, time, gc
from pretty_logger import PrettyLogger, prettylog

from controldb import ControlDB, construct_folder_path, construct_file_path, require_authorization

from models.root import ROOTBASE, UserTable
from sqlalchemy import Engine, create_engine, MetaData

@prettylog
class ControlDBManager():
    @property
    def name(self)->int:          
        return self.__dbName
    
    @property
    def rootPath(self)->int:          
        return self.__rootPath
    
    @property
    def userName(self)->dict:          
        return self.__userName    
    
    @property
    def authorized(self)->dict:          
        return self.__authorized   
    
    def __init__(self, dbName:str="database", rootPath:str=None, db_type: str = "mdb", logLevel: int = 30):    
        self.__dbName:str= dbName  
        self.__db_type:str= db_type       
        self.logLevel:int= logLevel   
        self.logger:PrettyLogger 
         
        self.__userName:str
        self.__password:str
        self.__authorized:bool=False

        # Get the absolute path of the current file
        if not rootPath:
            rootPath = os.getcwd()

        self.__rootPath = construct_folder_path(rootPath, folderSystem=dbName)

        self.databaseDir:dict={}    
     
    def setup(self, userName="admin", password=""):


        db:ControlDB = self.create("root", password=password, db_type=self.__db_type, base=ROOTBASE)
        db.row_create(UserTable, userName=userName, password=password)
        pass

    def create(self, fileName, password="", folderSystem: str|list[str] = None, base: MetaData|list[MetaData] = None)->ControlDB:

        db = ControlDB(fileName, rootPath=self.rootPath, folderSystem=folderSystem, db_type=self.__db_type, logLevel=self.logLevel)
        db.setup(password=password, base=base)
        
        self.databaseDir[db.name] = db
        return db

    def login(self, userName:str, password:str = ""):
        """
        Attempts to log in a user by checking if their folder exists in the database directory, 
        verifying their password, and establishing a connection upon successful authentication.

        Parameters:
            userName (str): The username of the user attempting to log in.
            password (str): The password provided by the user for authentication.

        Returns:
            None: Establishes a connection if authentication is successful.

        Raises:
            NameError: If the username does not exist in the database directory.
            ValueError: If the user ID cannot be retrieved or if the password is incorrect.
        """

        self.logger.info(f" -> Login attempt: '{userName}'.")

        # if self.validate_user(userName, password=password):
        #     # Load to database for user info
        #     self.__load(userName, password)            
        #     return True

        self.__userName=userName
        self.__password=password                 
        return True
        
    @require_authorization
    def add(self, fileName: str, folderSystem: str|list[str] = None, levels_up: int = 0, db_type: str = "mdb"):
        
        db = ControlDB(logLevel=self.logLevel)
        db.setup()
        
        self.databaseDir[fileName] = db
        pass


exit()


class ControlDBManagerAddToTop():
    @property
    def names(self)->int:          
        return self.databaseDir.keys()
    
    @property
    def withSubfolder(self)->list:          
        return 
     
    
    @staticmethod
    def get_folders(path: str) -> list:
        return [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    
    
    def get(self, name, subfolder:str=None):
        # print(self.databaseDir)
        if subfolder:
            return self.databaseDir[name].get_db(subfolder)
            
        else:
            return self.databaseDir[name]
    

    def __validate_password(self, userName, password:str):
        # Retrieve the user database controller
        name = "user"
        dbUser: DatabaseUser = self.get(name)
        path  = construct_file_path(userName, name)
        # print(path)
        dbUser.connect(path, password)

        # Fetch the user ID from the 'Info' table using the username
        userID = dbUser.get.id("Info", "username", userName)
        
        # Ensure the userID is valid before proceeding
        if not userID:
            self.logger.warning(f" -> Login attempt failed: Unable to retrieve user ID for '{userName}'.")
            self.__authorized = False
            raise ValueError(f"User ID for '{userName}' not found.")

        # Fetch the user's row data using the retrieved user ID
        row = dbUser.get.row("Info", userID[0])
        
        # Validate the password
        if password == row.password:
            self.__authorized = True
            self.logger.info(f"    ✅ - Login attempt successfully: Authorized user '{userName}'.")    

        else:
            # Log a warning for incorrect password attempts
            self.logger.warning(f"    ⛔ - Login attempt failed: Incorrect password for user '{userName}'.")
            self.__authorized = False
            # raise ValueError("Incorrect password.")
        return self.__authorized
        
    def validate_user(self, userName, password=""):
        self.logger.info(f" -> Validate user of database.")
        
        # Retrieve a list of all user folders within the main database folder
        userList = self.get_folders(self.mainPath)

        # Check if the given username exists in the database directory
        if userName not in userList:
            # Log a warning if the user is not found
            self.logger.warning(f" -> Login attempt failed: UserName '{userName}' not present in database.")

            # Raise an error indicating the user does not exist
            raise NameError(f"User '{userName}' not found in the database.")
        
        return self.__validate_password(userName, password)
        pass

    def __load(self, userName:str, password:str):
        self.__userName = userName
        for name in self.names:
            load = False

            if name in self.withSubfolder: 
                subFolder = name
                load = True
            else:
                subFolder=None

            db:DatabaseBroker = self.databaseDir[name]
            path  = construct_file_path(self.__userName, name, subFolder=subFolder)
            # print(path)
            
            if load == True: 
                db.load(self.get("user"))
            else:
                db.connect(path, password=password)
                pass
          
        
    def remove_all(self): 
        self.logger.warning("⛔ - Remove all databases")
        for name in self.names:
            self.logger.info(f" -> Remove Database: {name}")

            # if name in ["user"]:
            #     db:DatabaseControl = self.databaseDir[name]
            #     # print(db.fullPath)
            #     if db.remove(db.fullPath, exec=True):                    
            #         self.logger.info(f"   => Removed database: {name}")
            #     else:
            #         self.logger.info(f"   => Database not found: {name}")
            #     exit()

            if name == "bot":
                db:DatabaseBot = self.databaseDir[name]
                db.remove_all()
                pass
            elif name == "broker":
                db:DatabaseBroker = self.databaseDir[name]
                db.remove_all()
                pass
            # elif name in ["user", "wallet"]:
            # elif name in ["user"]:
            # elif name in ["wallet"]:
            #     pass
            else:
                db:DatabaseControl = self.databaseDir[name]
                # print(db.fullPath)
                if db.remove(db.fullPath, exec=True):                    
                    self.logger.info(f"   => Removed database: {name}")
                else:
                    self.logger.info(f"   => Database not found: {name}")
            pass
            
        # Construct the correct path
        self.userPath:str = os.path.join(self.mainPath, self.__userName)
        # print(self.userPath)
        self.databaseDir["user"].remove_folder(self.userPath)
        
             
    # def create(self, userName, password=""):
    #     for name in self.names:
    #         if name in self.withSubfolder: 
    #             subFolder = name
    #         else:
    #             subFolder = None

    #         db:ControlDB = self.databaseDir[name]

    #         if subFolder:
    #             folterPath = db.get.path(userName, subFolder=subFolder)
    #             db.create.path(folterPath)
    #         else:
    #             folterPath = db.get.path(userName, subFolder=subFolder)
    #             db.create.path(folterPath)

    #             filePath = db.get.file(userName, name, subFolder=subFolder)
    #             db.create.file(filePath, password=password)

    #             engine = db.connect(filePath, password)

    #             db.create.models(engine, name)   
        

    # def create_bot(self, userName):

    #     db:DatabaseControl = self.databaseDir[name]

    #     folterPath = db.get.path(userName, subFolder=subFolder)
    #     # print(folterPath)
    #     db.create.path(folterPath)

    #     filePath = db.get.file(userName, name, subFolder=subFolder)
    #     # print(filePath)
    #     db.create.file(filePath)

    #     engine = db.connect(filePath)

    #     db.create.models(engine, name)
    
