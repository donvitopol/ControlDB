
from ControlDB import ControlDBManager, ROOTBASE


if __name__ == "__main__":
    models = ROOTBASE
    fullname="Vito Pol"
    username="donvitopol"
    password="test"
    data = {
        "username": "John Doe",
        "fullname": "John Doe",
        "email": "john@example.com"  # ✅ required column
    }  

    cdbm = ControlDBManager(dbName="MyDB", logLevel = 10)