import pandas as pd
import functools
from sqlalchemy import Engine
from sqlalchemy.orm import sessionmaker, Session, declarative_base
from sqlalchemy import insert, MetaData, Table, select, text
from sqlalchemy import Column, Integer, String

from pretty_logger import PrettyLogger, prettylog

def require_authorization(func):
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        if not self.authorized:
            raise PermissionError(f"Unauthorized access to '{func.__name__}'")
        return func(self, *args, **kwargs)
    return wrapper
        

@prettylog
class UtilGetManager():
    def __init__(self, logLevel=30)->None:
        self.logger:PrettyLogger
        self.table_mapping:dict = None
        
        self.base:MetaData|list[MetaData] = None

        self.engine:Engine

    def connect(self, engine:Engine, session:Session, base:MetaData|list[MetaData]):
        self.engine:Engine = engine 
        self.session:Session = session
        self.base = base

        
        self.logger.debug(" -> UtilGetManager connected")

    def get_first_free_id(self, table_or_class, pk: str = "ID") -> int:
        """
        Find the first free ID in the given table. 
        If there are no gaps, returns max(id) + 1.

        Args:
            table_or_class (object): ORM model class or table object.
            pk (str): Name of the primary key column (default: "id").

        Returns:
            int: First available ID (starting from 1).
        """
        try:
            ids = [row[0] for row in self.session.execute(
                select(getattr(table_or_class, pk))
            ).all()]
            ids = sorted([i for i in ids if i is not None])

            if not ids:
                self.logger.debug(f"Table '{table_or_class.__tablename__}' is empty, returning ID = 1")
                return 1

            # Look for the first gap
            for expected, actual in enumerate(ids, start=1):
                if expected != actual:
                    self.logger.debug(f"First free id in '{table_or_class.__tablename__}': {expected}")
                    return expected

            next_id = ids[-1] + 1
            self.logger.debug(f"No gaps found in '{table_or_class.__tablename__}', next ID = {next_id}")
            return next_id

        except Exception as e:
            self.logger.error(f"Error finding first free ID in '{table_or_class}': {e}")
            return -1
        
    def get_ids(self, table_or_class: object, column_name: str, value: any) -> list[int]:
        """
        Retrieve IDs of rows where a specific column matches a given value.

        Parameters:
        - table_or_class: ORM class or Core Table object
        - column_name: Name of the column to filter by
        - value: Value to match in the column

        Returns:
        - Sorted list of IDs (integers)
        """
        if table_or_class is None:
            raise ValueError("Table object or ORM class cannot be None.")

        # ORM class
        if hasattr(table_or_class, "__table__"):
            column = getattr(table_or_class, column_name, None)
            if column is None:
                raise ValueError(f"Column '{column_name}' not found in ORM table '{table_or_class.__tablename__}'.")
            rows = self.session.query(table_or_class.id).filter(column == value).all()
            return sorted(row[0] for row in rows)

        # Core Table object
        if hasattr(table_or_class, "columns"):
            column = table_or_class.columns.get(column_name)
            if column is None:
                raise ValueError(f"Column '{column_name}' not found in Core table '{table_or_class.name}'.")
            if "id" not in table_or_class.columns:
                raise ValueError(f"Column 'id' not found in Core table '{table_or_class.name}'.")
            
            stmt = select(table_or_class.c.id).where(column == value)
            with self.engine.connect() as conn:
                result = conn.execute(stmt).all()
            return sorted(row[0] for row in result)

        raise ValueError("Input must be a SQLAlchemy ORM class or Core Table object.")
    
    def row(self, table_class: object, id: int):
        """
        Fetch a single row by ID from either an ORM class or Core Table.

        Parameters:
            table_class (object): The ORM class or Core Table object.
            id (int): The ID value to filter by.

        Returns:
            dict: A dictionary of the row data, or None if not found.
        """
        if table_class is None:
            raise ValueError("Table class cannot be None.")

        # Use .c.id for Core tables, .id for ORM classes
        filter_expr = table_class.c.ID if hasattr(table_class, "c") else table_class.ID
        result = self.session.query(table_class).filter(filter_expr == id).first()

        if not result:
            return None

        # Core Table row (RowMapping)
        if hasattr(result, "_mapping"):
            return dict(result._mapping)

        # ORM row (mapped class)
        if hasattr(result, "__table__"):
            return {col.name: getattr(result, col.name) for col in result.__table__.columns}

        # Fallback: generic object
        return {k: v for k, v in vars(result).items() if not k.startswith("_")}

    def column_as_list(self, table_or_class: object, column_name: str) -> list:
        """
        Retrieve all values from a single column as a list.

        Parameters:
        - table_or_class: ORM class or Core Table object
        - column_name: Name of the column to fetch

        Returns:
        - List of values from the specified column
        """
        if table_or_class is None:
            raise ValueError("Table object or ORM class cannot be None.")

        # ORM class
        if hasattr(table_or_class, "__table__"):
            column = getattr(table_or_class, column_name, None)
            if column is None:
                raise ValueError(f"Column '{column_name}' not found in ORM table '{table_or_class.__tablename__}'.")

            rows = self.session.query(column).all()
            return [row[0] for row in rows]

        # Core Table object
        if hasattr(table_or_class, "columns"):
            column = table_or_class.columns.get(column_name)
            if column is None:
                raise ValueError(f"Column '{column_name}' not found in Core table '{table_or_class.name}'.")

            with self.engine.connect() as conn:
                result = conn.execute(select(column))
                return [row[0] for row in result]

        raise ValueError("Input must be a SQLAlchemy ORM class or Table object.")
    
    def column_values(self, table_class: object, column_names: list[str]) -> dict[int, dict]:
        """
        Retrieve specific columns from a table and return them as a dictionary keyed by ID.
        Works with both ORM classes and Core tables.
        """
        if table_class is None:
            raise ValueError("No table class provided.")

        if not column_names:
            raise ValueError("No column names provided.")

        # Detect Core Table vs ORM Class
        if hasattr(table_class, "c"):  # Core Table
            columns = []
            for col_name in column_names:
                column = getattr(table_class.c, col_name, None)
                if column is None:
                    raise ValueError(f"Column '{col_name}' not found in Core table '{table_class}'.")
                columns.append(column)

            stmt = table_class.select().with_only_columns(table_class.c.id, *columns)
            rows = self.session.execute(stmt).all()

        else:  # ORM class
            columns = []
            for col_name in column_names:
                column = getattr(table_class, col_name, None)
                if column is None:
                    raise ValueError(f"Column '{col_name}' not found in ORM table '{table_class.__tablename__}'.")
                columns.append(column)

            rows = self.session.query(table_class.ID, *columns).all()

        # Build dictionary {id: {col1: val1, col2: val2, ...}}
        return {
            row[0]: {col: value for col, value in zip(column_names, row[1:])}
            for row in rows
        }

    def column_names(self, table_or_class: object) -> list[str]:
        """
        Return the column names of a SQLAlchemy Core Table or ORM class.

        :param table_or_class: Table object or ORM class
        :return: List of column names
        """
        # Core Table object
        if hasattr(table_or_class, "columns"):
            return [col.name for col in table_or_class.columns]

        # ORM class
        if hasattr(table_or_class, "__table__"):
            return [col.name for col in table_or_class.__table__.columns]

        raise ValueError("Input must be a SQLAlchemy Table object or ORM class.")
    def table(self, table_or_class: object) -> pd.DataFrame:
        """
        Retrieve all data from the specified table as a Pandas DataFrame.

        Args:
            table_or_class (object): Either the ORM table class or a Core Table object.

        Returns:
            pd.DataFrame or None: DataFrame containing table data, or None if an error occurs.
        """
        # Resolve table name
        if hasattr(table_or_class, "__tablename__"):
            table_name = table_or_class.__tablename__  # ORM class
        elif hasattr(table_or_class, "name"):
            table_name = table_or_class.name           # Core Table object
        else:
            self.logger.warning(" =! Get Table: INVALID table object provided")
            return None

        # SQL query (brackets added for MS Access compatibility)
        sql = f'SELECT * FROM [{table_name}]'

        try:
            with self.engine.connect() as connection:
                df = pd.read_sql_query(sql, connection)

                # Set ID column as the DataFrame index if it exists
                if "ID" in df.columns:
                    df = df.set_index("ID", drop=True)

                return df

        except Exception as e:
            self.logger.warning(f" =! Get Table: FAILED - {str(e)}")
            return None
    
class UtilManager():
    def __init__(self)->None: 
        # Internalize PrettyLogger
        self.logLevel:int 
        logCtr = PrettyLogger()     
        moduleName:str = "UtilManager"    
        self.logger:PrettyLogger = logCtr.get(moduleName)
        logCtr.add_stream(moduleName, level=self.logLevel)
        self.logger.debug(f'  - {moduleName} -> __init__') 

        # Database attributes
        self.base:MetaData|list[MetaData] = None
        self.engine: Engine = None
        self.session: Session = None  # private session

        # Utility manager for getters
        self.get = UtilGetManager(logLevel=self.logLevel)
    
    @ require_authorization
    def connect(self) -> None:
        """
        Connect the UtilManager to a database engine and register models.

        """       
        # Connect UtilGetManager
        self.get.connect(self.engine, self.session, self.base)

        self.logger.debug(" -> UtilManager connected")

    @ require_authorization
    def update_column_value(self, table_class: object, row_id: int, column_name: str, new_value):
        if not table_class:
            raise ValueError(f"Table '{table_class.__tablename__}' not found.")

        # Get column dynamically
        column = getattr(table_class, column_name, None)
        if column is None:
            raise ValueError(f"Column '{column_name}' not found in table '{table_class.__tablename__}'.")

        # Query the row
        row = self.session.query(table_class).filter(table_class.ID == row_id).first()
        if not row:
            raise ValueError(f"Row with id={row_id} not found in table '{table_class.__tablename__}'.")

        # Update the value
        setattr(row, column_name, new_value)

        # Commit the change
        self.session.commit()
        return True
    
    @ require_authorization
    def create_table(table_name: str, columns: dict, metadata=None):
        """
        Dynamically create a SQLAlchemy Table object without using ORM Base.

        :param table_name: Name of the table
        :param columns: Dictionary of column_name: column_type (e.g., {"name": String, "year": Integer})
        :param metadata: Optional SQLAlchemy MetaData object
        :return: SQLAlchemy Table object
        """
        if metadata is None:
            metadata = MetaData()

        # Always add an auto-incrementing 'id' column if not present
        if "id" not in columns:
            columns = {"id": Integer} | columns  # Python 3.9+ syntax

        # Build list of Column objects
        column_objs = []
        for col_name, col_type in columns.items():
            if col_name == "id":
                column_objs.append(Column(col_name, col_type, primary_key=True, autoincrement=True))
            else:
                column_objs.append(Column(col_name, col_type))

        # Create Table object dynamically
        table = Table(table_name, metadata, *column_objs)
        return table

    @ require_authorization
    def row_create(self, table_or_class: object, *args, **kwargs)->int:
        """
        Inserts a new record into the specified database table.

        Supports both ORM classes and SQLAlchemy Core Table objects.

        Parameters:
        - table_or_class (object): ORM class or Core Table object
        - *args: Positional arguments for ORM class constructor (ignored for Core Table)
        - **kwargs: Column values to insert

        Returns:
        - int: The ID of the newly created entry (if ORM with autoincrement id), 
            or None for Core Table objects.
        """
        if table_or_class is None:
            self.logger.warning("Error: Table object or ORM class is None!")
            return None

        # ORM class
        if hasattr(table_or_class, "__table__"):
            row = table_or_class(*args, **kwargs)
            self.session.add(row)
            self.session.commit()
            self.logger.debug(f" => Row added to ORM table '{table_or_class.__tablename__}'")
            # Try to return the new ID if it exists
            return getattr(row, "id", None)

        # Core Table object
        elif hasattr(table_or_class, "columns"):
            stmt = insert(table_or_class).values(**kwargs)
            with self.engine.connect() as conn:
                result = conn.execute(stmt)
                conn.commit()
            self.logger.debug(f" => Row added to Core table '{table_or_class.name}'")
            return None

        else:
            self.logger.warning("Error: Provided object is neither an ORM class nor a Table object.")
            return None
    
    @require_authorization
    def row_merge(self, table_or_class: object, row_id: int, data: dict) -> bool:
        """
        Merge a row: update only the columns provided in 'data'. Existing columns not in 'data' remain unchanged.

        Args:
            table_or_class (object): ORM class or Table object.
            row_id (int): Row ID to update.
            data (dict): Dictionary of column names and values to update.

        Returns:
            bool: True if row updated or inserted successfully, False otherwise.
        """
        if not table_or_class or not data:
            self.logger.warning("Error: Table/class or data is None!")
            return False

        row = self.session.query(table_or_class).filter_by(ID=row_id).first()
        
        if row:
            for key, value in data.items():
                if hasattr(row, key):
                    setattr(row, key, value)
                else:
                    self.logger.warning(f"Column '{key}' does not exist in table '{table_or_class.__tablename__}'")
            self.session.commit()
            self.logger.info(f"Row ID={row_id} merged successfully.")
            return True
        else:
            # Insert as new row if row_id does not exist
            new_data = {"ID": row_id, **data}
            stmt = insert(table_or_class).values(**new_data)
            self.session.execute(stmt)
            self.session.commit()
            self.logger.info(f"Row ID={row_id} inserted successfully.")
            return True

    @require_authorization
    def row_replace(self, table_or_class: object, row_id: int, data: dict) -> bool:
        """
        Replace a row: reset all columns to None except ID, then insert given data.

        Args:
            table_or_class (object): ORM class or Table object.
            row_id (int): Row ID to replace.
            data (dict): Dictionary of column names and values to insert.

        Returns:
            bool: True if row replaced successfully, False otherwise.
        """
        if not table_or_class or not data:
            self.logger.warning("Error: Table/class or data is None!")
            return False

        row = self.session.query(table_or_class).filter_by(ID=row_id).first()
        
        if row:
            for column in table_or_class.__table__.columns:
                col_name = column.name
                if col_name != "ID":
                    setattr(row, col_name, None)
            for key, value in data.items():
                if hasattr(row, key):
                    setattr(row, key, value)
            self.session.commit()
            self.logger.info(f"Row ID={row_id} replaced successfully.")
            return True
        else:
            # Insert new row if row_id does not exist
            new_data = {"ID": row_id, **data}
            for column in table_or_class.__table__.columns:
                col_name = column.name
                if col_name not in new_data:
                    new_data[col_name] = None
            stmt = insert(table_or_class).values(**new_data)
            self.session.execute(stmt)
            self.session.commit()
            self.logger.info(f"Row ID={row_id} inserted successfully.")
            return True
    
    @ require_authorization
    def table_names(self)->list:
        ''' Show table of Database.
        
        '''
        with self.engine.connect() as connection:      
            try: 
                with connection.begin():
                    # Set cursor of the database
                    cursor = connection.connection.cursor()  
                    tableNames = [name.table_name for name in cursor.tables() if not "MSys" in name.table_name]
                    connection.close() 

                    return tableNames
            except:
                self.logger.warning(f" =! Get table names: FAILED")
                # raise Exception('No connection!')
            pass

    @require_authorization
    def add_column(self, table_class: object, column_name: str, column_type):
        """
        Add a new column to an existing table.
        
        column_type: SQLAlchemy column type, e.g., String, Integer
        """
        if not table_class:
            raise ValueError("No table class provided.")

        # Generate raw SQL for adding a column
        table_name = table_class.__tablename__
        type_name = column_type.__visit_name__  # e.g., 'INTEGER', 'VARCHAR'

        sql = f'ALTER TABLE {table_name} ADD COLUMN {column_name} {type_name}'
        self.session.execute(sql)
        self.session.commit()

    @require_authorization
    def add_columns(self, table_class: object, columns: dict):
        """
        Add one or more new columns to an existing table.

        Args:
            table_class (object): The ORM class of the table.
            columns (dict): Dictionary where key = column name (str), 
                            value = SQLAlchemy column type (e.g., String, Integer).
                            Example: {"age": Integer, "name": String(255)}
        """
        if not table_class:
            raise ValueError("No table class provided.")

        table_name = table_class.__tablename__

        try:
            for column_name, column_type in columns.items():
                # Get SQLAlchemy type name (e.g., "VARCHAR", "INTEGER")
                type_name = column_type().compile(dialect=self.__engine.dialect)

                # Build SQL statement
                sql = f'ALTER TABLE {table_name} ADD COLUMN {column_name} {type_name}'

                self.logger.debug(f"Executing SQL: {sql}")
                self.session.execute(sql)

            self.session.commit()
            self.logger.info(f"Columns {list(columns.keys())} added to '{table_name}'")

        except Exception as e:
            self.session.rollback()
            self.logger.warning(f" =! Add Column(s): FAILED - {str(e)}")
            raise


    @ require_authorization
    def create_table_from_existing(self, table_name: str):
        """
        Dynamically create a Table object from an existing table in the database
        using a session query to read column names.
        """
        with self.engine.connect() as conn:
            stmt = text(f"SELECT * FROM [{table_name}] WHERE 1=0")
            result = conn.execute(stmt)
            column_names = result.keys()

        columns = []
        for name in column_names:
            if name.lower() == 'id':
                columns.append(Column(name, Integer, primary_key=True, autoincrement=True))
            else:
                columns.append(Column(name, String))  # default to String

        table = Table(table_name, self.metadata, *columns)
        return table

    
    # @ require_authorization
    # def create_table_from_existing(self, table_name: str):
    #     """
    #     Reflect an existing table from the database and return an ORM class.
    #     """
    #     Base = declarative_base()
    #     metadata = MetaData()

    #     # Reflect the table definition directly from the database
    #     table = Table(table_name, metadata, autoload_with=self.engine)

    #     # Dynamically create an ORM class bound to the reflected table
    #     orm_class = type(
    #         table_name.capitalize(),  # Class name
    #         (Base,),
    #         {"__table__": table},
    #     )

    #     return orm_class
    
    # @require_authorization
    # def create_table_from_existing(self, table_name: str):
    #     """
    #     Dynamically create an ORM class mapped to an existing table in the database.

    #     Args:
    #         table_name (str): The name of the existing table.

    #     Returns:
    #         ORM class mapped to the existing table.
    #     """
    #     with self.engine.connect() as conn:
    #         stmt = text(f"SELECT * FROM [{table_name}] WHERE 1=0")
    #         result = conn.execute(stmt)
    #         column_names = result.keys()

    #     # Build SQLAlchemy Columns dynamically
    #     columns = {}
    #     for name in column_names:
    #         if name.lower() == "id":
    #             columns[name] = Column(Integer, primary_key=True, autoincrement=True)
    #         else:
    #             columns[name] = Column(String)  # default to String

    #     # Dynamically create an ORM class
    #     orm_class = type(
    #         table_name.capitalize(),  # Class name
    #         (self.metadata,),
    #         {
    #             "__tablename__": table_name,
    #             "__table_args__": {"autoload_with": self.engine},
    #             **columns,
    #         },
    #     )

    #     return orm_class


    # def create_dynamic_table(table_name: str, columns: dict, metadata=None):
    #     """
    #     Create a dynamic table object using SQLAlchemy Core.

    #     :param table_name: Name of the table
    #     :param columns: Dictionary of column_name: column_type
    #                     e.g., {"name": String, "year": Integer}
    #     :param metadata: Optional SQLAlchemy MetaData object
    #     :return: SQLAlchemy Table object
    #     """
    #     if metadata is None:
    #         metadata = MetaData()

    #     # Always add an auto-incrementing 'id' column if not present
    #     if "id" not in columns:
    #         columns = {"id": Integer} | columns  # Python 3.9+ syntax

    #     # Build list of Column objects
    #     column_objs = []
    #     for col_name, col_type in columns.items():
    #         if col_name == "id":
    #             column_objs.append(Column(col_name, col_type, primary_key=True, autoincrement=True))
    #         else:
    #             column_objs.append(Column(col_name, col_type))

    #     # Create Table object dynamically
    #     table = Table(table_name, metadata, *column_objs)
    #     return table







    