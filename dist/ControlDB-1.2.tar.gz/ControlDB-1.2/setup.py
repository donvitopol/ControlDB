from setuptools import setup, find_packages

setup(
    name='ControlDB',
    version='1.2',
    packages=find_packages(),  # Automatically find all sub-packages
    author='Vito Pol',
    author_email='don_vito_pol@hotmail.com',
    python_requires='>=3.11',
    install_requires=[
        "pandas>=2.0",
        "pyodbc>=4.0",
        "SQLAlchemy>=2.0",
        "pretty_logger>=0.1",  # Replace with actual version if needed
    ],
    description=(
        "ControlDB: Utilities for database management, "
        "processing sample replicates, and logging."
    ),
    classifiers=[
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
    ],
)